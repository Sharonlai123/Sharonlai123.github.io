// Simulating user data storage using localStorage
function getUsers() {
    return JSON.parse(localStorage.getItem('users')) || [];
}

function saveUser(user) {
    const users = getUsers();
    users.push(user);
    localStorage.setItem('users', JSON.stringify(users));
}

// Sign Up Functionality
function signUp() {
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const signupErrorMessage = document.getElementById('signup-error-message');

    const users = getUsers();
    const existingUser = users.find(user => user.email === email);

    if (existingUser) {
        signupErrorMessage.textContent = 'User already exists. Please sign in.';
    } else if (email && password) {
        saveUser({ email, password });
        signupErrorMessage.textContent = 'Account created! Please sign in.';
        showLoginPage(); // Redirect to login after sign-up
    } else {
        signupErrorMessage.textContent = 'Please fill in both fields.';
    }
}

// Login Functionality
function login() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');

    const users = getUsers();
    const user = users.find(user => user.email === email && user.password === password);

    if (user) {
        document.getElementById('loginPage').style.display = 'none';
        document.getElementById('gradeTrackerPage').style.display = 'block';
    } else {
        errorMessage.textContent = 'Incorrect email or password. Try again.';
    }
}

// Toggle between login and sign-up pages
function showSignUpPage() {
    document.getElementById('loginPage').style.display = 'none';
    document.getElementById('signupPage').style.display = 'block';
}

function showLoginPage() {
    document.getElementById('signupPage').style.display = 'none';
    document.getElementById('loginPage').style.display = 'block';
}

// Grade management
let grades = [];
let editIndex = null;

// Add grade function
function addGrade() {
    const subject = document.getElementById('subject').value;
    const grade = document.getElementById('grade').value;

    if (subject && grade) {
        grades.push({ subject, grade });
        displayGrades();
        clearForm();
    }
}

// Edit grade function
function editGrade(index) {
    const gradeToEdit = grades[index];
    document.getElementById('subject').value = gradeToEdit.subject;
    document.getElementById('grade').value = gradeToEdit.grade;

    document.getElementById('addGradeBtn').style.display = 'none';
    document.getElementById('updateGradeBtn').style.display = 'block';

    editIndex = index;
}

// Update grade function
function updateGrade() {
    const subject = document.getElementById('subject').value;
    const grade = document.getElementById('grade').value;

    if (subject && grade && editIndex !== null) {
        grades[editIndex] = { subject, grade };
        displayGrades();
        clearForm();

        document.getElementById('addGradeBtn').style.display = 'block';
        document.getElementById('updateGradeBtn').style.display = 'none';
        editIndex = null;
    }
}

// Display grades in the list
function displayGrades() {
    const gradesList = document.getElementById('gradesList');
    gradesList.innerHTML = '';

    grades.forEach((entry, index) => {
        const li = document.createElement('li');
        li.innerHTML = `Subject: ${entry.subject}, Grade: ${entry.grade} 
            <button onclick="editGrade(${index})">Edit</button>`;
        gradesList.appendChild(li);
    });
}

// Clear the form after adding/updating a grade
function clearForm() {
    document.getElementById('subject').value = '';
    document.getElementById('grade').value = '';
}